// This file enables loading css from node_module in vue-typescript demo
module.exports = {

}
